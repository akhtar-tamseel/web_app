# Zero Day Financing - Smart Financial Literacy Platform

## Overview

Zero Day Financing is a comprehensive financial literacy platform designed to provide culturally-adapted, multilingual financial education. The application combines modern web technologies with AI-powered personalization to deliver region-specific financial knowledge through an intuitive learning management system.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The client-side application is built with React 18 using TypeScript and modern tooling:
- **Framework**: React with Wouter for routing (lightweight alternative to React Router)
- **Styling**: Tailwind CSS with custom design system using CSS variables for theming
- **UI Components**: Custom component library built on Radix UI primitives for accessibility
- **State Management**: TanStack Query (React Query) for server state management
- **Internationalization**: React-i18next for multi-language support
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
The server follows a REST API architecture built with Express.js:
- **Runtime**: Node.js with TypeScript and ESM modules
- **Framework**: Express.js with middleware for JSON parsing and request logging
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **AI Integration**: OpenAI GPT-4 for personalized financial advice and chatbot functionality
- **Development**: Hot reloading with Vite integration for seamless full-stack development

### Database Design
The application uses PostgreSQL with the following key entities:
- **Users**: Core user profiles with language/region preferences and progress tracking
- **Modules**: Learning content with hierarchical structure and prerequisites
- **User Progress**: Individual learning progress and completion tracking
- **Chat Sessions**: Persistent AI chatbot conversations with localization
- **Daily Challenges**: Gamification elements for user engagement

## Key Components

### Learning Management System
- **Module System**: Structured learning paths with prerequisites and difficulty levels
- **Progress Tracking**: Comprehensive analytics on user completion rates and time spent
- **Content Localization**: Dynamic content adaptation based on user's region and language
- **Assessment Engine**: Scoring system with performance analytics

### AI-Powered Chatbot
- **OpenAI Integration**: GPT-4-powered financial mentor with cultural context awareness
- **Multilingual Support**: Region-specific financial advice in user's preferred language
- **Persistent Sessions**: Chat history storage with session management
- **Context Awareness**: User progress and module completion integration for personalized responses

### Internationalization System
- **Multi-language Support**: Currently supports English, Hindi, Spanish, Portuguese, Arabic, and Swahili
- **Regional Adaptation**: Financial advice tailored to specific countries (India, Nigeria, Brazil, Philippines, Egypt, Kenya)
- **Cultural Context**: AI system trained on region-specific financial products and cultural norms

### Gamification Features
- **Daily Challenges**: Engagement system with point rewards
- **Progress Streaks**: User retention through streak tracking
- **Achievement System**: Level-based progression (beginner, intermediate, advanced)
- **Point System**: Comprehensive scoring for completed activities

## Data Flow

### Learning Path Flow
1. User selects preferred language and region during onboarding
2. System presents culturally-adapted learning modules based on user preferences
3. Progress tracking records completion percentages, time spent, and scores
4. Prerequisites system unlocks advanced modules based on completion

### AI Chatbot Flow
1. User initiates chat session with personalized context (language, region, progress)
2. OpenAI API processes query with cultural and regional context
3. System generates localized financial advice with region-specific examples
4. Chat history persisted for continuity across sessions

### Content Localization Flow
1. Base financial content stored in universal format
2. AI engine adapts content based on user's region and language preferences
3. Local financial products, regulations, and cultural norms integrated
4. Dynamic content delivery through React-i18next integration

## External Dependencies

### Core Infrastructure
- **Database**: Neon PostgreSQL (serverless PostgreSQL solution)
- **AI Services**: OpenAI GPT-4 API for intelligent financial mentoring
- **Session Storage**: PostgreSQL with connect-pg-simple for session management

### Frontend Libraries
- **UI Framework**: Radix UI for accessible component primitives
- **Styling**: Tailwind CSS with class-variance-authority for component variants
- **Data Fetching**: TanStack Query for efficient server state management
- **Internationalization**: i18next ecosystem for comprehensive localization
- **Form Handling**: React Hook Form with Zod validation

### Development Dependencies
- **Build System**: Vite with React plugin and TypeScript support
- **Database Management**: Drizzle Kit for schema migrations and introspection
- **Code Quality**: TypeScript for type safety across full stack
- **Development Tools**: Replit-specific plugins for enhanced development experience

## Deployment Strategy

### Production Build Process
1. **Frontend**: Vite builds React application with optimized bundles and code splitting
2. **Backend**: esbuild compiles TypeScript server code to ESM format for Node.js
3. **Database**: Drizzle migrations ensure schema consistency across environments
4. **Assets**: Static files served through Express with proper caching headers

### Environment Configuration
- **Development**: Hot reloading with Vite dev server and TypeScript watch mode
- **Production**: Optimized builds with environment-specific configurations
- **Database**: Connection pooling and migration management through Drizzle
- **API Keys**: Secure environment variable management for OpenAI and database credentials

### Scalability Considerations
- **Database**: Serverless PostgreSQL scales automatically with usage
- **AI Services**: OpenAI API calls optimized with context management and caching strategies
- **Frontend**: Static asset optimization and CDN-ready build output
- **Session Management**: Database-backed sessions for horizontal scaling capability

The architecture prioritizes cultural adaptation, educational effectiveness, and technical scalability while maintaining a focus on financial literacy accessibility across diverse global markets.

## Recent Changes (July 2025)

### Authentication System Implementation
- **Date**: July 24, 2025
- **Status**: ✅ Complete
- **Changes**: 
  - Implemented PostgreSQL-backed authentication system with user login/signup
  - Created comprehensive auth pages with form validation and error handling
  - Added session management with user state persistence
  - Fixed all page components to properly use authenticated user data
  - Added user profile dropdown with logout functionality
  - Created demo user for immediate testing: demo@zerodayfinancing.com / password123

### AI Chatbot Enhancement - Open Source Solution
- **Date**: July 24, 2025  
- **Status**: ✅ Complete with Open Source Knowledge Base
- **Changes**:
  - **Replaced OpenAI dependency** with comprehensive open source financial knowledge base
  - **No external API costs** - fully self-contained financial advice system
  - **Region-specific content** covering India, USA, UK, Canada, Australia, and global markets
  - **Comprehensive coverage** of budgeting, saving, investing, and debt management
  - **Detailed responses** including specific financial products, apps, and strategies
  - **Smart keyword matching** to provide contextually relevant advice
  - **Zero latency** - instant responses without API calls or quota limitations

### Current Platform Status
- **Authentication**: Fully functional with database storage
- **Learning Modules**: 3 sample modules available (Smart Budgeting, Smart Saving, Investment Basics)
- **AI Chatbot**: Fully open source knowledge base with comprehensive financial advice
- **Progress Tracking**: Database-backed user progress system
- **UI/UX**: Complete responsive design with dark mode support
- **Internationalization**: 6 languages supported with regional adaptation