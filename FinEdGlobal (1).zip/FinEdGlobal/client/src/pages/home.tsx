import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useQuery } from '@tanstack/react-query';
import { Header } from '@/components/header';
import { ModuleCard } from '@/components/module-card';
import { Chatbot } from '@/components/chatbot';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ProgressBar } from '@/components/progress-bar';
import { Trophy, Bot, Play, Clock } from 'lucide-react';
import type { Module, UserProgress, DailyChallenge, User } from '@shared/schema';

interface HomeProps {
  user: User;
  onLogout: () => void;
}

export default function Home({ user, onLogout }: HomeProps) {
  const { t } = useTranslation();
  const [isChatbotOpen, setIsChatbotOpen] = useState(false);

  // Fetch modules
  const { data: modules = [], isLoading: modulesLoading } = useQuery<Module[]>({
    queryKey: ['/api/modules'],
  });

  // Fetch user progress
  const { data: progress = [], isLoading: progressLoading } = useQuery<UserProgress[]>({
    queryKey: ['/api/users', user.id, 'progress'],
  });

  // Fetch daily challenges
  const { data: challenges = [], isLoading: challengesLoading } = useQuery<DailyChallenge[]>({
    queryKey: ['/api/challenges'],
  });

  const handleModuleClick = (moduleId: number) => {
    // Navigate to module page
    window.location.href = `/module/${moduleId}`;
  };

  const getModuleProgress = (moduleId: number) => {
    return progress.find(p => p.moduleId === moduleId);
  };

  const isModuleLocked = (module: Module) => {
    if (!module.prerequisites || module.prerequisites.length === 0) return false;
    
    return module.prerequisites.some(prereq => {
      const prereqModule = modules.find(m => m.category === prereq);
      if (!prereqModule) return false;
      
      const prereqProgress = getModuleProgress(prereqModule.id);
      return !prereqProgress || prereqProgress.progressPercentage < 100;
    });
  };

  const completedModules = progress.filter(p => p.progressPercentage === 100).length;
  const totalProgress = modules.length > 0 ? Math.round((completedModules / modules.length) * 100) : 0;

  const todayChallenge = challenges[0]; // Get first available challenge

  return (
    <div className="min-h-screen bg-neutral-50">
      <Header user={user} onLogout={onLogout} />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-primary to-blue-600 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                {t('hero.welcome', { name: user.username })}
              </h2>
              <p className="text-blue-100 text-lg mb-6">
                {t('hero.subtitle')}
              </p>
              
              {/* Progress Overview */}
              <Card className="bg-white/10 backdrop-blur-sm border-0 mb-6">
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-4 text-white">{t('progress.title')}</h3>
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <div className="text-2xl font-bold text-white">{completedModules}</div>
                      <div className="text-blue-100 text-sm">{t('progress.modulesCompleted')}</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-white">{user.streakDays}</div>
                      <div className="text-blue-100 text-sm">{t('progress.dayStreak')}</div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-2 text-white">
                      <span>{t('progress.currentLevel')}: {user.currentLevel}</span>
                      <span>{totalProgress}%</span>
                    </div>
                    <div className="w-full bg-white/20 rounded-full h-2">
                      <div 
                        className="bg-accent h-2 rounded-full transition-all duration-300" 
                        style={{ width: `${totalProgress}%` }}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Button 
                className="bg-accent hover:bg-yellow-600 text-neutral-900 font-semibold"
                onClick={() => {
                  const nextModule = modules.find(m => !isModuleLocked(m) && (!getModuleProgress(m.id) || getModuleProgress(m.id)!.progressPercentage < 100));
                  if (nextModule) handleModuleClick(nextModule.id);
                }}
              >
                <Play className="w-4 h-4 mr-2" />
                {t('hero.continueLearning')}
              </Button>
            </div>

            {/* Hero Image */}
            <div className="hidden md:block">
              <div className="w-full h-80 bg-white/10 rounded-xl flex items-center justify-center">
                <div className="text-center">
                  <div className="text-6xl mb-4">🌍📱💡</div>
                  <p className="text-blue-100">Global Financial Education</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Learning Modules */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-neutral-700 mb-4">
              {t('modules.title')}
            </h2>
            <p className="text-lg text-neutral-500 max-w-2xl mx-auto">
              {t('modules.subtitle')}
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {modules.map((module) => (
              <ModuleCard
                key={module.id}
                module={module}
                progress={getModuleProgress(module.id)}
                isLocked={isModuleLocked(module)}
                onModuleClick={handleModuleClick}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Quick Actions */}
      <section className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-8">
            {/* Daily Challenge */}
            {todayChallenge && (
              <Card className="bg-gradient-to-r from-accent to-yellow-500 border-0">
                <CardContent className="p-8 text-white">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center mr-4">
                      <Trophy className="text-2xl" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold">{t('challenges.title')}</h3>
                      <p className="text-yellow-100">
                        {t('challenges.subtitle', { points: todayChallenge.points })}
                      </p>
                    </div>
                  </div>
                  <p className="text-lg mb-6">{todayChallenge.description}</p>
                  <Button className="bg-white text-neutral-900 font-semibold hover:bg-gray-100">
                    {t('challenges.startChallenge')}
                  </Button>
                </CardContent>
              </Card>
            )}

            {/* AI Mentor */}
            <Card className="bg-gradient-to-r from-primary to-blue-600 border-0">
              <CardContent className="p-8 text-white">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center mr-4">
                    <Bot className="text-2xl" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold">{t('chatbot.title')}</h3>
                    <p className="text-blue-100">{t('chatbot.subtitle')}</p>
                  </div>
                </div>
                <p className="text-lg mb-6">
                  Get instant answers to your financial questions with culturally relevant advice
                </p>
                <Button 
                  className="bg-white text-neutral-900 font-semibold hover:bg-gray-100"
                  onClick={() => setIsChatbotOpen(true)}
                >
                  Ask a Question
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Cultural Adaptation Showcase */}
      <section className="bg-neutral-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-neutral-700 mb-4">
              Adapted for Your Region
            </h2>
            <p className="text-lg text-neutral-500 max-w-2xl mx-auto">
              Financial education that understands your local culture, economy, and financial landscape
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <div className="text-center">
              <div className="w-16 h-16 bg-secondary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">🗺️</span>
              </div>
              <h3 className="text-xl font-semibold text-neutral-700 mb-2">Local Examples</h3>
              <p className="text-neutral-500">
                Learn with real examples from your country's banking system, investment options, and financial products
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">👥</span>
              </div>
              <h3 className="text-xl font-semibold text-neutral-700 mb-2">Cultural Context</h3>
              <p className="text-neutral-500">
                Content adapted to local values, family structures, and cultural attitudes towards money
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">🌐</span>
              </div>
              <h3 className="text-xl font-semibold text-neutral-700 mb-2">Native Language</h3>
              <p className="text-neutral-500">
                Available in 15+ languages with proper cultural translation, not just literal word conversion
              </p>
            </div>
          </div>

          {/* Example Content Adaptation */}
          <Card>
            <CardContent className="p-8">
              <h3 className="text-xl font-semibold text-neutral-700 mb-6">
                Example: Budgeting Lesson Adapted for India
              </h3>
              <div className="grid md:grid-cols-2 gap-8">
                <div>
                  <h4 className="font-semibold text-neutral-700 mb-3">Generic Version</h4>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <p className="text-neutral-600 text-sm">
                      "Allocate 50% of your income to needs, 30% to wants, and 20% to savings."
                    </p>
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold text-neutral-700 mb-3">India-Adapted Version</h4>
                  <div className="bg-blue-50 rounded-lg p-4">
                    <p className="text-neutral-600 text-sm">
                      "In India, consider family obligations: 40% for household needs, 20% for family support, 20% for wants, and 20% for PPF and SIP investments."
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Floating Chatbot Button */}
      <div className="fixed bottom-6 right-6 z-40">
        <Button
          className="bg-primary hover:bg-blue-600 text-white rounded-full w-14 h-14 shadow-lg relative"
          onClick={() => setIsChatbotOpen(true)}
        >
          <Bot className="w-6 h-6" />
          {/* Notification badge */}
          <div className="absolute -top-2 -right-2 w-6 h-6 bg-accent rounded-full flex items-center justify-center">
            <span className="text-xs font-bold text-neutral-900">3</span>
          </div>
        </Button>
      </div>

      {/* Chatbot */}
      <Chatbot
        isOpen={isChatbotOpen}
        onClose={() => setIsChatbotOpen(false)}
        userId={user.id}
        language={user.preferredLanguage}
        region={user.region}
      />
    </div>
  );
}
