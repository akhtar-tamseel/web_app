import { useState, useEffect } from 'react';
import { useParams } from 'wouter';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Header } from '@/components/header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Clock, Check, ChevronRight, Play } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import type { Module, UserProgress, User } from '@shared/schema';

interface ModulePageProps {
  user: User;
  onLogout: () => void;
}

export default function ModulePage({ user, onLogout }: ModulePageProps) {
  const { id } = useParams<{ id: string }>();
  const moduleId = parseInt(id || '0');
  const [currentLesson, setCurrentLesson] = useState(0);
  const queryClient = useQueryClient();

  // Fetch module data
  const { data: module, isLoading: moduleLoading } = useQuery<Module>({
    queryKey: ['/api/modules', moduleId],
  });

  // Fetch user progress for this module
  const { data: progress } = useQuery<UserProgress>({
    queryKey: ['/api/users', user.id, 'progress', moduleId],
    enabled: !!moduleId,
  });

  // Update progress mutation
  const updateProgressMutation = useMutation({
    mutationFn: async (progressData: { 
      userId: number; 
      moduleId: number; 
      progressPercentage: number;
      timeSpent: number;
    }) => {
      const response = await apiRequest('POST', '/api/progress', progressData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users', user.id, 'progress'] });
    },
  });

  const lessons = (module?.content as any)?.lessons || [];
  const totalLessons = lessons.length;
  const progressPercentage = progress?.progressPercentage || 0;

  const handleLessonComplete = () => {
    if (currentLesson < totalLessons - 1) {
      setCurrentLesson(currentLesson + 1);
    }
    
    // Update progress
    const newProgress = Math.round(((currentLesson + 1) / totalLessons) * 100);
    updateProgressMutation.mutate({
      userId: user.id,
      moduleId,
      progressPercentage: newProgress,
      timeSpent: (progress?.timeSpent || 0) + (lessons[currentLesson]?.duration || 0),
    });
  };

  const handleBackToHome = () => {
    window.location.href = '/';
  };

  if (moduleLoading || !module) {
    return (
      <div className="min-h-screen bg-neutral-50">
        <Header user={user} onLogout={onLogout} />
        <div className="flex items-center justify-center h-96">
          <div className="text-lg">Loading...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-50">
      <Header user={user} />
      
      {/* Module Header */}
      <section className="bg-white border-b">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center mb-6">
            <Button 
              variant="ghost" 
              className="mr-4"
              onClick={handleBackToHome}
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Modules
            </Button>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="md:col-span-2">
              <h1 className="text-3xl font-bold text-neutral-700 mb-4">
                {module.title}
              </h1>
              <p className="text-lg text-neutral-600 mb-6">
                {module.description}
              </p>
              
              <div className="flex items-center space-x-4 mb-6">
                <Badge variant="outline">
                  {module.difficulty}
                </Badge>
                <div className="flex items-center text-sm text-neutral-500">
                  <Clock className="w-4 h-4 mr-1" />
                  {module.estimatedDuration} minutes
                </div>
              </div>

              <div className="mb-6">
                <div className="flex justify-between text-sm mb-2">
                  <span>Progress</span>
                  <span>{progressPercentage}%</span>
                </div>
                <Progress value={progressPercentage} className="h-2" />
              </div>
            </div>

            <div>
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Module Content</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {lessons.map((lesson: any, index: number) => (
                      <div
                        key={index}
                        className={`flex items-center justify-between p-3 rounded-lg cursor-pointer transition-colors ${
                          index === currentLesson
                            ? 'bg-primary/10 border border-primary/20'
                            : index < currentLesson
                            ? 'bg-green-50 border border-green-200'
                            : 'bg-gray-50 border border-gray-200'
                        }`}
                        onClick={() => index <= currentLesson && setCurrentLesson(index)}
                      >
                        <div className="flex items-center space-x-3">
                          <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                            index < currentLesson
                              ? 'bg-green-500 text-white'
                              : index === currentLesson
                              ? 'bg-primary text-white'
                              : 'bg-gray-300 text-gray-600'
                          }`}>
                            {index < currentLesson ? (
                              <Check className="w-3 h-3" />
                            ) : index === currentLesson ? (
                              <Play className="w-3 h-3" />
                            ) : (
                              index + 1
                            )}
                          </div>
                          <div>
                            <p className="font-medium text-sm">{lesson.title}</p>
                            <p className="text-xs text-neutral-500">{lesson.duration} min</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Lesson Content */}
      <section className="py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="md:col-span-2">
              <Card>
                <CardContent className="p-8">
                  {lessons[currentLesson] ? (
                    <div className="space-y-6">
                      <div>
                        <h2 className="text-2xl font-bold text-neutral-700 mb-4">
                          {lessons[currentLesson].title}
                        </h2>
                        <Badge className="mb-6">
                          Lesson {currentLesson + 1} of {totalLessons}
                        </Badge>
                      </div>

                      {/* Sample lesson content */}
                      <div className="prose max-w-none">
                        <h3>Learning Objectives</h3>
                        <ul>
                          <li>Understand the key concepts of this financial topic</li>
                          <li>Learn how to apply these concepts in the Indian context</li>
                          <li>Practice with real-world examples and scenarios</li>
                        </ul>

                        <h3>Content Overview</h3>
                        <p>
                          This lesson covers important financial concepts adapted specifically for the Indian market. 
                          You'll learn about local banking products, regulatory requirements, and cultural 
                          considerations that affect financial decision-making.
                        </p>

                        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 my-6">
                          <h4 className="font-semibold text-blue-900 mb-2">💡 Cultural Insight</h4>
                          <p className="text-blue-800 text-sm">
                            In India, family financial planning often involves multiple generations. 
                            Consider how your financial decisions impact not just yourself, but your 
                            extended family network.
                          </p>
                        </div>

                        <h3>Practical Example</h3>
                        <p>
                          Let's look at how this concept applies in a real Indian scenario:
                        </p>
                        
                        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                          <p className="text-green-800 text-sm">
                            <strong>Example:</strong> Priya, a software engineer in Bangalore, wants to 
                            plan her finances. She needs to consider her monthly salary, family 
                            contributions, local tax implications (like Section 80C deductions), 
                            and available investment options like PPF, ELSS, and FDs.
                          </p>
                        </div>
                      </div>

                      <div className="flex justify-between items-center pt-6 border-t">
                        <Button 
                          variant="outline"
                          disabled={currentLesson === 0}
                          onClick={() => setCurrentLesson(currentLesson - 1)}
                        >
                          Previous Lesson
                        </Button>
                        
                        <Button 
                          onClick={handleLessonComplete}
                          disabled={updateProgressMutation.isPending}
                        >
                          {currentLesson === totalLessons - 1 ? 'Complete Module' : 'Next Lesson'}
                          <ChevronRight className="w-4 h-4 ml-2" />
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <h3 className="text-xl font-semibold text-neutral-700 mb-4">
                        Module Complete!
                      </h3>
                      <p className="text-neutral-600 mb-6">
                        Congratulations on completing this module. You can now move on to the next one.
                      </p>
                      <Button onClick={handleBackToHome}>
                        Back to Modules
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            <div>
              {/* Module Stats */}
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle className="text-lg">Your Stats</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Completion</span>
                        <span>{progressPercentage}%</span>
                      </div>
                      <Progress value={progressPercentage} className="h-2" />
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Time Spent</span>
                      <span>{progress?.timeSpent || 0} min</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Lessons Completed</span>
                      <span>{currentLesson} / {totalLessons}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Tips */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">💡 Quick Tips</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <p>• Take notes as you learn</p>
                    <p>• Practice with real examples</p>
                    <p>• Ask the AI mentor if you have questions</p>
                    <p>• Apply concepts in your daily life</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
