import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

const resources = {
  en: {
    translation: {
      nav: {
        learn: 'Learn',
        progress: 'Progress',
        community: 'Community',
        resources: 'Resources'
      },
      hero: {
        welcome: 'Welcome back, {{name}}!',
        subtitle: 'Continue your journey to financial independence with personalized lessons adapted to your region and culture.',
        continueLearning: 'Continue Learning'
      },
      modules: {
        title: 'Learning Modules',
        subtitle: 'Master essential financial skills with culturally adapted content designed for your region',
        continue: 'Continue',
        completed: 'Completed',
        locked: 'Locked'
      },
      progress: {
        title: 'Your Progress',
        modulesCompleted: 'Modules Completed',
        dayStreak: 'Day Streak',
        currentLevel: 'Current Level'
      },
      chatbot: {
        title: 'AI Financial Mentor',
        subtitle: 'Available 24/7 in your language',
        placeholder: 'Ask me anything about finance...',
        send: 'Send'
      },
      challenges: {
        title: "Today's Challenge",
        subtitle: 'Complete to earn {{points}} points',
        startChallenge: 'Start Challenge'
      }
    }
  },
  hi: {
    translation: {
      nav: {
        learn: 'सीखें',
        progress: 'प्रगति',
        community: 'समुदाय',
        resources: 'संसाधन'
      },
      hero: {
        welcome: 'वापस स्वागत है, {{name}}!',
        subtitle: 'अपने क्षेत्र और संस्कृति के अनुकूल व्यक्तिगत पाठों के साथ वित्तीय स्वतंत्रता की अपनी यात्रा जारी रखें।',
        continueLearning: 'सीखना जारी रखें'
      },
      modules: {
        title: 'शिक्षण मॉड्यूल',
        subtitle: 'अपने क्षेत्र के लिए डिज़ाइन की गई सांस्कृतिक रूप से अनुकूलित सामग्री के साथ आवश्यक वित्तीय कौशल में महारत हासिल करें',
        continue: 'जारी रखें',
        completed: 'पूरा हुआ',
        locked: 'बंद'
      },
      progress: {
        title: 'आपकी प्रगति',
        modulesCompleted: 'पूरे किए गए मॉड्यूल',
        dayStreak: 'दिन की लकीर',
        currentLevel: 'वर्तमान स्तर'
      },
      chatbot: {
        title: 'AI वित्तीय सलाहकार',
        subtitle: 'आपकी भाषा में 24/7 उपलब्ध',
        placeholder: 'वित्त के बारे में कुछ भी पूछें...',
        send: 'भेजें'
      },
      challenges: {
        title: 'आज की चुनौती',
        subtitle: '{{points}} अंक अर्जित करने के लिए पूरा करें',
        startChallenge: 'चुनौती शुरू करें'
      }
    }
  },
  es: {
    translation: {
      nav: {
        learn: 'Aprender',
        progress: 'Progreso',
        community: 'Comunidad',
        resources: 'Recursos'
      },
      hero: {
        welcome: '¡Bienvenido de vuelta, {{name}}!',
        subtitle: 'Continúa tu viaje hacia la independencia financiera con lecciones personalizadas adaptadas a tu región y cultura.',
        continueLearning: 'Continuar Aprendiendo'
      },
      modules: {
        title: 'Módulos de Aprendizaje',
        subtitle: 'Domina habilidades financieras esenciales con contenido culturalmente adaptado diseñado para tu región',
        continue: 'Continuar',
        completed: 'Completado',
        locked: 'Bloqueado'
      },
      progress: {
        title: 'Tu Progreso',
        modulesCompleted: 'Módulos Completados',
        dayStreak: 'Racha de Días',
        currentLevel: 'Nivel Actual'
      },
      chatbot: {
        title: 'Mentor Financiero IA',
        subtitle: 'Disponible 24/7 en tu idioma',
        placeholder: 'Pregúntame cualquier cosa sobre finanzas...',
        send: 'Enviar'
      },
      challenges: {
        title: 'Desafío de Hoy',
        subtitle: 'Completa para ganar {{points}} puntos',
        startChallenge: 'Comenzar Desafío'
      }
    }
  }
};

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng: 'en',
    fallbackLng: 'en',
    interpolation: {
      escapeValue: false
    }
  });

export default i18n;
