export const SUPPORTED_LANGUAGES = [
  { code: 'en', name: 'English', nativeName: 'English' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिंदी' },
  { code: 'es', name: 'Spanish', nativeName: 'Español' },
  { code: 'pt', name: 'Portuguese', nativeName: 'Português' },
  { code: 'ar', name: 'Arabic', nativeName: 'العربية' },
  { code: 'sw', name: 'Swahili', nativeName: 'Kiswahili' },
];

export const REGIONS = [
  { code: 'global', name: 'Global' },
  { code: 'india', name: 'India' },
  { code: 'nigeria', name: 'Nigeria' },
  { code: 'brazil', name: 'Brazil' },
  { code: 'philippines', name: 'Philippines' },
  { code: 'egypt', name: 'Egypt' },
  { code: 'kenya', name: 'Kenya' },
];

export const FINANCIAL_CATEGORIES = [
  'budgeting',
  'saving',
  'investing',
  'credit',
  'insurance',
  'retirement'
];

export const DIFFICULTY_LEVELS = [
  'beginner',
  'intermediate',
  'advanced'
];

export const MODULE_ICONS = {
  budgeting: 'calculator',
  saving: 'piggy-bank',
  investing: 'chart-line',
  credit: 'credit-card',
  insurance: 'shield-alt',
  retirement: 'calendar-alt'
};

export const DEFAULT_USER = {
  id: 1,
  username: 'demo_user',
  email: 'demo@zerodayfinancing.com',
  preferredLanguage: 'en',
  region: 'india',
  currentLevel: 'beginner',
  totalPoints: 850,
  streakDays: 7
};
