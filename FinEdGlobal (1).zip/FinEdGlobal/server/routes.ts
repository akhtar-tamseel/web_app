import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { generateFinancialAdvice } from "./services/openai";
import { insertUserSchema, insertChatSessionSchema, insertUserProgressSchema, insertUserChallengeSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Auth routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists" });
      }
      
      const user = await storage.createUser(userData);
      const { password, ...userWithoutPassword } = user;
      
      res.json({ user: userWithoutPassword });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(400).json({ message: "Invalid user data" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      const user = await storage.getUserByEmail(email);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // Update last active date
      await storage.updateUser(user.id, { lastActiveDate: new Date() });
      
      const { password: _, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ message: "Login failed" });
    }
  });

  // Module routes
  app.get("/api/modules", async (req, res) => {
    try {
      const modules = await storage.getAllModules();
      res.json(modules);
    } catch (error) {
      console.error("Failed to fetch modules:", error);
      res.status(500).json({ message: "Failed to fetch modules" });
    }
  });

  app.get("/api/modules/:id", async (req, res) => {
    try {
      const moduleId = parseInt(req.params.id);
      const module = await storage.getModule(moduleId);
      
      if (!module) {
        return res.status(404).json({ message: "Module not found" });
      }
      
      res.json(module);
    } catch (error) {
      console.error("Failed to fetch module:", error);
      res.status(500).json({ message: "Failed to fetch module" });
    }
  });

  // Progress routes
  app.get("/api/users/:userId/progress", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const progress = await storage.getUserProgress(userId);
      res.json(progress);
    } catch (error) {
      console.error("Failed to fetch progress:", error);
      res.status(500).json({ message: "Failed to fetch progress" });
    }
  });

  app.post("/api/progress", async (req, res) => {
    try {
      const progressData = insertUserProgressSchema.parse(req.body);
      const progress = await storage.updateUserProgress(progressData);
      res.json(progress);
    } catch (error) {
      console.error("Failed to update progress:", error);
      res.status(400).json({ message: "Invalid progress data" });
    }
  });

  // Chat routes
  app.post("/api/chat", async (req, res) => {
    try {
      const { userId, message, language = "en", region = "global", sessionId } = req.body;
      
      if (!userId || !message) {
        return res.status(400).json({ message: "Missing required fields" });
      }

      // Get user context
      const user = await storage.getUser(userId);
      const userProgress = await storage.getUserProgress(userId);
      const completedModules = userProgress
        .filter(p => p.progressPercentage === 100)
        .map(p => p.moduleId.toString());

      const userContext = {
        currentLevel: user?.currentLevel,
        completedModules,
      };

      // Generate AI response
      const aiResponse = await generateFinancialAdvice(message, language, region, userContext);
      
      // Get or create chat session
      let chatSession = await storage.getChatSession(userId, sessionId);
      if (!chatSession) {
        chatSession = await storage.createChatSession({
          userId,
          sessionId,
          messages: [],
          language,
          region,
        });
      }

      // Update chat session with new messages
      const newMessages = [
        ...chatSession.messages as any[],
        { role: "user", content: message, timestamp: new Date() },
        { role: "assistant", content: aiResponse.message, timestamp: new Date() }
      ];

      await storage.updateChatSession(chatSession.id, newMessages);

      res.json({
        message: aiResponse.message,
        suggestions: aiResponse.suggestions,
        sessionId
      });
    } catch (error) {
      console.error("Chat error:", error);
      
      // Provide fallback response when chat service fails
      const fallbackResponse = {
        message: `I'm here to help with your financial questions! While I'm experiencing some technical issues, I can still provide guidance on budgeting, saving, investing, and financial planning.

What would you like to learn about today?`,
        suggestions: [
          "Help me create a budget",
          "How can I start saving money?", 
          "What are good investment options?"
        ]
      };
      
      res.json(fallbackResponse);
    }
  });

  // Challenge routes
  app.get("/api/challenges", async (req, res) => {
    try {
      const challenges = await storage.getDailyChallenges();
      res.json(challenges);
    } catch (error) {
      console.error("Failed to fetch challenges:", error);
      res.status(500).json({ message: "Failed to fetch challenges" });
    }
  });

  app.post("/api/challenges/complete", async (req, res) => {
    try {
      const challengeData = insertUserChallengeSchema.parse(req.body);
      const userChallenge = await storage.completeChallenge(challengeData);
      
      // Update user points
      const user = await storage.getUser(challengeData.userId);
      if (user) {
        const challenge = await storage.getDailyChallenges();
        const completedChallenge = challenge.find(c => c.id === challengeData.challengeId);
        if (completedChallenge) {
          await storage.updateUser(user.id, { 
            totalPoints: user.totalPoints + completedChallenge.points 
          });
        }
      }
      
      res.json(userChallenge);
    } catch (error) {
      console.error("Failed to complete challenge:", error);
      res.status(400).json({ message: "Invalid challenge data" });
    }
  });

  // User profile routes
  app.get("/api/users/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Failed to fetch user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  app.patch("/api/users/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const updates = req.body;
      
      const updatedUser = await storage.updateUser(userId, updates);
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Failed to update user:", error);
      res.status(500).json({ message: "Failed to update user" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
