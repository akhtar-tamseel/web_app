// Open source financial knowledge base for Zero Day Financing
// This replaces the OpenAI dependency with curated financial literacy content

export interface KnowledgeResponse {
  message: string;
  suggestions?: string[];
  category?: string;
}

interface FinancialTopic {
  keywords: string[];
  responses: {
    [region: string]: {
      message: string;
      suggestions: string[];
    };
  };
  defaultResponse: {
    message: string;
    suggestions: string[];
  };
}

// Comprehensive financial knowledge base
const FINANCIAL_KNOWLEDGE: Record<string, FinancialTopic> = {
  budgeting: {
    keywords: ['budget', 'budgeting', 'expense', 'spending', 'money management', 'track expenses'],
    responses: {
      india: {
        message: `**Smart Budgeting for India** 🇮🇳

Creating a budget that works in India's economic environment:

**1. Income Tracking**
- Calculate your monthly take-home salary after PF, ESI, and taxes
- Include irregular income (bonuses, freelance work)
- Factor in festival bonuses (Diwali bonus, etc.)

**2. Essential Expenses (50%)**
- Rent/EMI, utilities, groceries, transportation
- Health insurance premiums
- Family support (if applicable)

**3. Discretionary Spending (30%)**
- Entertainment, dining out, shopping
- Subscriptions (Netflix, Spotify, etc.)
- Personal care and hobbies

**4. Savings & Investments (20%)**
- Emergency fund (6 months expenses)
- PPF, ELSS, SIP in mutual funds
- Gold savings for festivals

**Indian-Specific Tips:**
- Use apps like Money Manager, Walnut, or ET Money
- Track cash transactions (still common in India)
- Plan for festival expenses throughout the year
- Consider seasonal variations (AC bills in summer)`,
        suggestions: [
          "Best budgeting apps available in India?",
          "How to save money during festivals?",
          "Should I include gold in my budget?"
        ]
      },
      global: {
        message: `**Effective Budgeting Strategies**

Master your money with these proven budgeting methods:

**1. The 50/30/20 Rule**
- 50% for needs (rent, utilities, groceries)
- 30% for wants (entertainment, dining out)
- 20% for savings and debt repayment

**2. Zero-Based Budgeting**
- Every dollar has a purpose
- Income minus expenses equals zero
- Review and adjust monthly

**3. Envelope Method**
- Allocate cash for each category
- When envelope is empty, stop spending
- Great for controlling discretionary spending

**4. Track Everything**
- Use budgeting apps or spreadsheets
- Review weekly to stay on track
- Identify spending patterns and leaks

**Getting Started:**
- Calculate your net income
- List all fixed expenses
- Set realistic limits for variable expenses
- Build in a small buffer for unexpected costs`,
        suggestions: [
          "What's the best budgeting method for beginners?",
          "How do I stick to my budget?",
          "What budgeting apps do you recommend?"
        ]
      }
    },
    defaultResponse: {
      message: "Budgeting is the foundation of financial success. Start by tracking your income and expenses, then use the 50/30/20 rule as a guideline.",
      suggestions: ["How do I start budgeting?", "What expenses should I track?", "Best budgeting tools?"]
    }
  },

  saving: {
    keywords: ['saving', 'save money', 'emergency fund', 'savings account', 'financial goals'],
    responses: {
      india: {
        message: `**Smart Saving Strategies for India** 💰

Build wealth with these India-specific saving approaches:

**1. Emergency Fund Priority**
- Target: 6-12 months of expenses
- Keep in high-yield savings account (4-6% interest)
- Consider liquid funds for better returns
- Don't invest emergency fund in equity

**2. Savings Account Options**
- **High-yield accounts**: IDFC First, DBS, AU Bank (6-7%)
- **Zero-balance accounts**: Kotak 811, ICICI iWish
- **Salary accounts**: Often offer higher interest rates

**3. Traditional Indian Savings**
- **PPF**: 15-year lock-in, tax benefits, 7.1% interest
- **NSC**: 5-year term, tax deduction under 80C
- **ELSS**: Mutual funds with 3-year lock-in, tax benefits
- **Gold**: Physical gold, Gold ETFs, or digital gold

**4. Systematic Saving**
- Auto-debit on salary day
- Start with ₹1,000-5,000/month
- Increase savings with salary hikes
- Use apps like Paytm Money, Groww for SIPs

**Pro Tips:**
- Save before you spend, not what's left over
- Use recurring deposits for specific goals
- Consider debt funds for 2-3 year goals`,
        suggestions: [
          "Best high-interest savings accounts in India?",
          "PPF vs ELSS - which is better?",
          "How much should I save monthly?"
        ]
      },
      global: {
        message: `**Building Your Savings Foundation** 🏦

Create financial security with strategic saving:

**1. Emergency Fund First**
- 3-6 months of living expenses
- Keep in high-yield savings account
- Easily accessible for true emergencies
- Don't invest this money in risky assets

**2. Automate Your Savings**
- Set up automatic transfers on payday
- "Pay yourself first" principle
- Start small and increase gradually
- Use separate savings accounts for different goals

**3. High-Yield Savings Options**
- Online banks often offer better rates
- Money market accounts
- Certificates of deposit for longer terms
- Treasury bills for government backing

**4. Savings Goals Strategy**
- Short-term (under 2 years): High-yield savings
- Medium-term (2-5 years): CDs, bonds
- Long-term (5+ years): Consider investing
- Emergency fund: Always liquid and safe

**Building the Habit:**
- Start with any amount you can afford
- Celebrate small wins
- Track your progress visually
- Review and adjust goals regularly`,
        suggestions: [
          "What's a good savings rate?",
          "Best high-yield savings accounts?",
          "How to save for multiple goals?"
        ]
      }
    },
    defaultResponse: {
      message: "Saving money is crucial for financial security. Start with an emergency fund of 3-6 months expenses in a high-yield savings account.",
      suggestions: ["How much should I save?", "Best savings accounts?", "Emergency fund basics?"]
    }
  },

  investing: {
    keywords: ['invest', 'investment', 'stocks', 'mutual funds', 'portfolio', 'returns'],
    responses: {
      india: {
        message: `**Investment Guide for India** 📈

Build long-term wealth with these Indian investment options:

**1. Mutual Funds (Recommended for beginners)**
- **Large Cap**: Stable, lower risk (Axis Bluechip, Mirae Asset Large Cap)
- **Mid Cap**: Higher growth potential, higher risk
- **ELSS**: Tax saving funds with 3-year lock-in
- **Index Funds**: Low cost, track Nifty/Sensex

**2. Direct Equity**
- Start with blue-chip stocks (TCS, Infosys, HDFC Bank)
- Use Zerodha, Groww, or Angel One for trading
- Learn fundamental analysis before stock picking
- Never invest borrowed money

**3. Fixed Income**
- **PPF**: 7.1% tax-free returns, 15-year lock-in
- **NSC**: 5-year government bonds
- **Corporate FDs**: Higher returns than bank FDs
- **Debt Mutual Funds**: Professional management

**4. Alternative Investments**
- **Gold**: Digital gold, Gold ETFs, Gold bonds
- **REITs**: Real estate investment trusts
- **Government Bonds**: Safe, steady returns

**Investment Strategy:**
- Start SIP with ₹1,000-5,000/month
- Diversify across asset classes
- Don't try to time the market
- Stay invested for 5+ years minimum
- Review portfolio annually

**Tax Implications:**
- LTCG on equity: 10% above ₹1 lakh
- Dividend income: Added to total income
- Use 80C for tax-saving investments`,
        suggestions: [
          "Which mutual funds are best for beginners?",
          "How much should I invest in stocks vs mutual funds?",
          "What's the difference between SIP and lump sum?"
        ]
      },
      global: {
        message: `**Smart Investing Fundamentals** 🌱

Build wealth through strategic long-term investing:

**1. Investment Basics**
- **Stocks**: Ownership in companies, higher risk/reward
- **Bonds**: Loans to governments/companies, lower risk
- **Index Funds**: Diversified, low-cost market tracking
- **ETFs**: Exchange-traded funds, flexible and liquid

**2. Risk vs Return**
- Higher potential returns = higher risk
- Diversification reduces overall risk
- Don't put all money in one investment
- Match investments to your timeline

**3. Getting Started**
- Emergency fund first (3-6 months expenses)
- Start with broad market index funds
- Dollar-cost averaging through regular investing
- Increase investments with income growth

**4. Investment Timeline**
- **Short-term (1-2 years)**: High-yield savings, CDs
- **Medium-term (3-5 years)**: Balanced funds, bonds
- **Long-term (5+ years)**: Stock index funds, growth stocks

**Key Principles:**
- Time in market beats timing the market
- Compound interest is your best friend
- Keep costs low (expense ratios under 0.5%)
- Rebalance portfolio annually
- Don't panic during market downturns

**Common Mistakes to Avoid:**
- Trying to time the market
- Putting all money in one stock
- Emotional buying and selling
- Ignoring fees and taxes`,
        suggestions: [
          "What's the best investment for beginners?",
          "How much should I invest monthly?",
          "Index funds vs individual stocks?"
        ]
      }
    },
    defaultResponse: {
      message: "Investing helps build long-term wealth. Start with index funds or diversified mutual funds after building an emergency fund.",
      suggestions: ["Best investments for beginners?", "How much risk should I take?", "When should I start investing?"]
    }
  },

  debt: {
    keywords: ['debt', 'loan', 'credit card', 'emi', 'interest rate', 'payoff'],
    responses: {
      india: {
        message: `**Debt Management in India** 💳

Smart strategies to manage and eliminate debt:

**1. Credit Card Debt (Highest Priority)**
- Interest rates: 24-48% annually
- Pay minimum amount to avoid penalties
- Pay full amount to avoid interest charges
- Consider balance transfer to lower rate cards

**2. Personal Loans**
- Interest rates: 10-24%
- Fixed EMI makes budgeting easier
- Avoid taking for consumption
- Prepayment can save significant interest

**3. Home Loans**
- Interest rates: 7-9%
- Longest tenure, lowest rates
- Tax benefits under 80C and 24(b)
- Consider part-prepayment to reduce tenure

**4. Education Loans**
- Interest rates: 8-15%
- Tax deduction on interest payments
- Moratorium period available
- Some banks offer interest rate concessions

**Debt Elimination Strategy:**
- **Avalanche Method**: Pay highest interest rate first
- **Snowball Method**: Pay smallest amount first
- Always pay more than minimum
- Avoid taking new debt while paying off existing

**Prevention Tips:**
- Build emergency fund to avoid debt
- Use credit cards responsibly
- Compare interest rates before borrowing
- Read all loan terms carefully`,
        suggestions: [
          "How to pay off credit card debt faster?",
          "Should I prepay my home loan?",
          "Best strategy for multiple debts?"
        ]
      },
      global: {
        message: `**Effective Debt Management** 🎯

Take control of your debt with proven strategies:

**1. Debt Assessment**
- List all debts with balances and interest rates
- Calculate total monthly payments
- Identify highest-cost debt first
- Track debt-to-income ratio

**2. Repayment Strategies**
- **Avalanche**: Pay minimums, extra to highest rate
- **Snowball**: Pay minimums, extra to smallest balance
- **Hybrid**: Combine both methods strategically
- Always pay more than minimum when possible

**3. Credit Card Management**
- Pay full balance to avoid interest
- Keep utilization under 30%
- Don't close old cards (hurts credit score)
- Consider balance transfers for high rates

**4. Loan Optimization**
- Refinance high-rate loans when possible
- Extra payments go directly to principal
- Bi-weekly payments can save years of interest
- Avoid loan extensions that increase total cost

**Prevention Strategy:**
- Build emergency fund to avoid borrowing
- Live below your means
- Use credit responsibly
- Monitor credit reports regularly

**Red Flags:**
- Only making minimum payments
- Using credit for basic expenses
- Taking cash advances
- Missing payment due dates`,
        suggestions: [
          "What's the fastest way to pay off debt?",
          "Should I consolidate my debts?",
          "How to improve my credit score?"
        ]
      }
    },
    defaultResponse: {
      message: "Focus on paying off high-interest debt first, especially credit cards. Always pay more than the minimum when possible.",
      suggestions: ["Debt avalanche vs snowball method?", "How to negotiate with creditors?", "Best debt consolidation options?"]
    }
  }
};

export function getFinancialAdvice(
  userMessage: string,
  language: string = "en",
  region: string = "global",
  userContext?: {
    currentLevel?: string;
    completedModules?: string[];
    preferences?: any;
  }
): KnowledgeResponse {
  const message = userMessage.toLowerCase();
  
  // Find matching topic based on keywords
  let matchedTopic: string | null = null;
  let maxMatches = 0;
  
  for (const [topic, data] of Object.entries(FINANCIAL_KNOWLEDGE)) {
    const matches = data.keywords.filter(keyword => 
      message.includes(keyword.toLowerCase())
    ).length;
    
    if (matches > maxMatches) {
      maxMatches = matches;
      matchedTopic = topic;
    }
  }
  
  if (matchedTopic && FINANCIAL_KNOWLEDGE[matchedTopic]) {
    const topicData = FINANCIAL_KNOWLEDGE[matchedTopic];
    const regionResponse = topicData.responses[region];
    
    if (regionResponse) {
      return {
        message: regionResponse.message,
        suggestions: regionResponse.suggestions,
        category: matchedTopic
      };
    } else {
      return {
        message: topicData.defaultResponse.message,
        suggestions: topicData.defaultResponse.suggestions,
        category: matchedTopic
      };
    }
  }
  
  // General financial literacy response
  return {
    message: `**Welcome to Zero Day Financing!** 🎓

I'm your personal financial literacy assistant. I can help you with:

📊 **Budgeting & Expense Management**
- Creating realistic budgets that work
- Tracking expenses effectively
- Managing cash flow

💰 **Saving & Emergency Funds**
- Building emergency funds
- High-yield savings strategies
- Goal-based saving plans

📈 **Investment Education**
- Beginner-friendly investment options
- Risk assessment and portfolio building
- Local investment opportunities

💳 **Debt Management**
- Debt elimination strategies
- Credit score improvement
- Loan optimization

${region === 'india' ? '🇮🇳 **India-Specific Guidance**\nI understand Indian financial products, tax implications, and cultural financial practices!' : '🌍 **Regional Expertise**\nTailored advice for your local financial landscape!'}

What financial topic would you like to explore today?`,
    suggestions: [
      "Help me create a budget",
      "How should I start investing?",
      "Best ways to save money",
      "How to pay off debt faster"
    ],
    category: "general"
  };
}

// Additional utility functions for enhanced responses
export function getPersonalizedAdvice(
  topic: string,
  userLevel: string = "beginner",
  completedModules: string[] = []
): string {
  const levelAdjustments = {
    beginner: "Let's start with the basics and build a strong foundation.",
    intermediate: "You're ready for more advanced strategies and optimization.",
    advanced: "Let's explore sophisticated techniques and advanced planning."
  };
  
  return levelAdjustments[userLevel as keyof typeof levelAdjustments] || levelAdjustments.beginner;
}

export function getRegionalContext(region: string): string {
  const regionalInfo = {
    india: "🇮🇳 Indian financial landscape with rupee-based examples, local banking, and tax considerations",
    usa: "🇺🇸 US financial system with dollar-based examples and American financial products",
    uk: "🇬🇧 UK financial environment with pound-based examples and British financial services",
    canada: "🇨🇦 Canadian financial context with CAD examples and Canadian investment options",
    australia: "🇦🇺 Australian financial system with AUD examples and local financial products"
  };
  
  return regionalInfo[region as keyof typeof regionalInfo] || "🌍 Global financial principles with universal applicability";
}