// Open source financial advice service using local knowledge base
import { getFinancialAdvice, getPersonalizedAdvice, getRegionalContext, type KnowledgeResponse } from './knowledgeBase';

export interface ChatMessage {
  role: "user" | "assistant" | "system";
  content: string;
  timestamp: Date;
}

export interface ChatResponse {
  message: string;
  suggestions?: string[];
}

// Primary function that uses open source knowledge base
export async function generateFinancialAdvice(
  userMessage: string,
  language: string = "en",
  region: string = "global",
  userContext?: {
    currentLevel?: string;
    completedModules?: string[];
    preferences?: any;
  }
): Promise<ChatResponse> {
  try {
    // Use the open source knowledge base for financial advice
    const knowledgeResponse = getFinancialAdvice(userMessage, language, region, userContext);
    
    // Add personalized touches based on user context
    let enhancedMessage = knowledgeResponse.message;
    
    if (userContext?.currentLevel) {
      const personalizedNote = getPersonalizedAdvice(
        knowledgeResponse.category || "general",
        userContext.currentLevel,
        userContext.completedModules || []
      );
      enhancedMessage += `\n\n**Personalized Note:** ${personalizedNote}`;
    }
    
    // Add progress encouragement if user has completed modules
    if (userContext?.completedModules && userContext.completedModules.length > 0) {
      enhancedMessage += `\n\n🎉 **Great Progress!** You've completed ${userContext.completedModules.length} learning module(s). Keep building your financial knowledge!`;
    }
    
    return {
      message: enhancedMessage,
      suggestions: knowledgeResponse.suggestions || []
    };
    
  } catch (error) {
    console.error("Knowledge base error:", error);
    
    // Ultimate fallback for any errors
    return {
      message: `I'm here to help with your financial journey! I can provide guidance on:

📊 **Budgeting & Expense Tracking**
💰 **Saving Strategies & Emergency Funds** 
📈 **Investment Basics & Portfolio Building**
🏦 **Banking & Financial Products**
🎯 **Goal-Based Financial Planning**

${region === 'india' ? 'I understand Indian financial products and can help with region-specific advice!' : 'I can provide advice tailored to your region and financial system.'}

What specific area would you like to explore?`,
      suggestions: [
        "Help me create a monthly budget",
        "How can I start saving money?",
        "What investment options should I consider?"
      ]
    };
  }
}

// Legacy OpenAI integration (kept for future premium features)
// Note: This function is no longer the primary advice generator

export async function generateModuleContent(
  topic: string,
  level: string,
  region: string,
  language: string
): Promise<any> {
  try {
    const prompt = `Create educational content for a financial literacy module about "${topic}" for ${level} level learners in ${region}. 

Requirements:
- Adapt examples and case studies to ${region}'s economic context
- Include local financial products, banking systems, and regulations
- Use culturally appropriate scenarios and values
- Structure content with clear learning objectives
- Include practical exercises and real-world applications
- Format as JSON with sections: introduction, lessons, exercises, summary

Language: ${language}
Region: ${region}
Level: ${level}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
      max_tokens: 1500,
    });

    return JSON.parse(response.choices[0].message.content || "{}");
  } catch (error) {
    console.error("Failed to generate module content:", error);
    throw new Error("Failed to generate educational content");
  }
}
