import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Header } from '@/components/header';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Calendar, Trophy, Clock, Target, TrendingUp, Star } from 'lucide-react';
import type { Module, UserProgress, UserChallenge, User } from '@shared/schema';

interface ProgressPageProps {
  user: User;
  onLogout: () => void;
}

export default function ProgressPage({ user, onLogout }: ProgressPageProps) {

  // Fetch modules
  const { data: modules = [] } = useQuery<Module[]>({
    queryKey: ['/api/modules'],
  });

  // Fetch user progress
  const { data: progress = [] } = useQuery<UserProgress[]>({
    queryKey: ['/api/users', user.id, 'progress'],
  });

  // Fetch completed challenges
  const { data: challenges = [] } = useQuery<UserChallenge[]>({
    queryKey: ['/api/users', user.id, 'challenges'],
  });

  const completedModules = progress.filter(p => p.progressPercentage === 100).length;
  const totalModules = modules.length;
  const overallProgress = totalModules > 0 ? Math.round((completedModules / totalModules) * 100) : 0;
  const totalTimeSpent = progress.reduce((acc, p) => acc + (p.timeSpent || 0), 0);
  const averageScore = progress.filter(p => p.score).reduce((acc, p, _, arr) => acc + (p.score || 0) / arr.length, 0);

  return (
    <div className="min-h-screen bg-neutral-50">
      <Header user={user} onLogout={onLogout} />
      
      {/* Progress Header */}
      <section className="bg-gradient-to-r from-primary to-blue-600 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">Your Learning Progress</h1>
          <p className="text-blue-100 text-lg">
            Track your journey to financial literacy mastery
          </p>
        </div>
      </section>

      {/* Stats Overview */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Target className="w-6 h-6 text-primary" />
                </div>
                <div className="text-2xl font-bold text-neutral-700">{overallProgress}%</div>
                <div className="text-sm text-neutral-500">Overall Progress</div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Trophy className="w-6 h-6 text-secondary" />
                </div>
                <div className="text-2xl font-bold text-neutral-700">{completedModules}</div>
                <div className="text-sm text-neutral-500">Modules Completed</div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Clock className="w-6 h-6 text-accent" />
                </div>
                <div className="text-2xl font-bold text-neutral-700">{totalTimeSpent}</div>
                <div className="text-sm text-neutral-500">Minutes Learned</div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Star className="w-6 h-6 text-purple-600" />
                </div>
                <div className="text-2xl font-bold text-neutral-700">{Math.round(averageScore)}%</div>
                <div className="text-sm text-neutral-500">Average Score</div>
              </CardContent>
            </Card>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Module Progress */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5" />
                  Module Progress
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {modules.map((module) => {
                    const moduleProgress = progress.find(p => p.moduleId === module.id);
                    const progressPercentage = moduleProgress?.progressPercentage || 0;
                    const score = moduleProgress?.score;
                    const isCompleted = progressPercentage === 100;

                    return (
                      <div key={module.id} className="space-y-2">
                        <div className="flex justify-between items-center">
                          <div>
                            <h4 className="font-medium text-neutral-700">{module.title}</h4>
                            <p className="text-sm text-neutral-500">{module.category}</p>
                          </div>
                          <div className="flex items-center gap-2">
                            {isCompleted && score && (
                              <Badge variant="default" className="bg-green-100 text-green-800">
                                {score}%
                              </Badge>
                            )}
                            <Badge variant={isCompleted ? "default" : progressPercentage > 0 ? "secondary" : "outline"}>
                              {isCompleted ? "Completed" : progressPercentage > 0 ? "In Progress" : "Not Started"}
                            </Badge>
                          </div>
                        </div>
                        <div className="flex justify-between text-sm text-neutral-500 mb-1">
                          <span>Progress</span>
                          <span>{progressPercentage}%</span>
                        </div>
                        <Progress value={progressPercentage} className="h-2" />
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Learning Streak & Achievements */}
            <div className="space-y-6">
              {/* Learning Streak */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="w-5 h-5" />
                    Learning Streak
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center">
                    <div className="text-4xl font-bold text-primary mb-2">
                      {user.streakDays}
                    </div>
                    <p className="text-neutral-600 mb-4">Days in a row</p>
                    <div className="flex justify-center space-x-1">
                      {Array.from({ length: 7 }, (_, i) => (
                        <div
                          key={i}
                          className={`w-6 h-6 rounded-full ${
                            i < user.streakDays % 7
                              ? 'bg-primary'
                              : 'bg-gray-200'
                          }`}
                        />
                      ))}
                    </div>
                    <p className="text-sm text-neutral-500 mt-2">This week</p>
                  </div>
                </CardContent>
              </Card>

              {/* Achievements */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Trophy className="w-5 h-5" />
                    Recent Achievements
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                      <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                        <Trophy className="w-4 h-4 text-white" />
                      </div>
                      <div>
                        <h4 className="font-medium text-green-900">Savings Expert</h4>
                        <p className="text-sm text-green-700">Completed Smart Saving module</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
                      <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                        <Star className="w-4 h-4 text-white" />
                      </div>
                      <div>
                        <h4 className="font-medium text-blue-900">High Scorer</h4>
                        <p className="text-sm text-blue-700">Scored 95% on budgeting quiz</p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3 p-3 bg-purple-50 rounded-lg">
                      <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center">
                        <Calendar className="w-4 h-4 text-white" />
                      </div>
                      <div>
                        <h4 className="font-medium text-purple-900">Consistent Learner</h4>
                        <p className="text-sm text-purple-700">7-day learning streak</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
