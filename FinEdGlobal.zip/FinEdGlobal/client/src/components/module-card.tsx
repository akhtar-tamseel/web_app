import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Clock, MapPin, Star, Check, Lock } from 'lucide-react';
import { ProgressBar } from './progress-bar';
import { MODULE_ICONS } from '@/lib/constants';
import type { Module, UserProgress } from '@shared/schema';

interface ModuleCardProps {
  module: Module;
  progress?: UserProgress;
  isLocked?: boolean;
  onModuleClick: (moduleId: number) => void;
}

export function ModuleCard({ module, progress, isLocked, onModuleClick }: ModuleCardProps) {
  const progressPercentage = progress?.progressPercentage || 0;
  const isCompleted = progressPercentage === 100;
  const score = progress?.score;

  const getModuleIcon = (category: string) => {
    const iconName = MODULE_ICONS[category as keyof typeof MODULE_ICONS] || 'book';
    // Return appropriate icon component based on iconName
    switch (iconName) {
      case 'calculator': return '🧮';
      case 'piggy-bank': return '🐷';
      case 'chart-line': return '📈';
      case 'credit-card': return '💳';
      case 'shield-alt': return '🛡️';
      case 'calendar-alt': return '📅';
      default: return '📚';
    }
  };

  const getStatusColor = () => {
    if (isLocked) return 'bg-gray-100';
    if (isCompleted) return 'bg-green-100';
    if (progressPercentage > 0) return 'bg-blue-100';
    return 'bg-gray-100';
  };

  const getIconColor = () => {
    if (isLocked) return 'text-gray-500';
    if (isCompleted) return 'text-green-600';
    if (progressPercentage > 0) return 'text-blue-600';
    return 'text-gray-500';
  };

  return (
    <Card 
      className={`hover:shadow-lg transition-shadow cursor-pointer ${
        isLocked ? 'opacity-60' : ''
      }`}
      onClick={() => !isLocked && onModuleClick(module.id)}
    >
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className={`w-12 h-12 ${getStatusColor()} rounded-lg flex items-center justify-center text-2xl`}>
            {getModuleIcon(module.category)}
          </div>
          <div className="flex items-center text-sm text-neutral-500">
            <Clock className="w-4 h-4 mr-1" />
            <span>{module.estimatedDuration} min</span>
          </div>
        </div>

        <h3 className="text-xl font-semibold text-neutral-700 mb-2">
          {module.title}
        </h3>
        <p className="text-neutral-500 mb-4 text-sm">
          {module.description}
        </p>

        {!isLocked && (
          <ProgressBar 
            percentage={progressPercentage} 
            className="mb-4"
          />
        )}

        <div className="flex items-center justify-between">
          {isLocked ? (
            <Badge variant="secondary" className="flex items-center gap-1">
              <Lock className="w-3 h-3" />
              Locked
            </Badge>
          ) : isCompleted ? (
            <Badge variant="default" className="bg-green-100 text-green-800 flex items-center gap-1">
              <Check className="w-3 h-3" />
              Completed
            </Badge>
          ) : progressPercentage > 0 ? (
            <Badge className="flex items-center gap-1">
              <MapPin className="w-3 h-3" />
              India Specific
            </Badge>
          ) : (
            <Badge variant="outline">
              New
            </Badge>
          )}

          <div className="flex items-center gap-2 text-sm">
            {isCompleted && score && (
              <div className="text-accent font-medium flex items-center gap-1">
                <Star className="w-4 h-4" />
                {score}%
              </div>
            )}
            {!isLocked && (
              <span className={`font-medium ${
                isCompleted ? 'text-green-600' : 'text-secondary'
              }`}>
                {isCompleted ? 'Review' : progressPercentage > 0 ? 'Continue' : 'Start'}
              </span>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
