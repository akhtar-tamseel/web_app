import { 
  users, modules, userProgress, chatSessions, dailyChallenges, userChallenges,
  type User, type InsertUser, type Module, type InsertModule, 
  type UserProgress, type InsertUserProgress, type ChatSession, type InsertChatSession,
  type DailyChallenge, type InsertDailyChallenge, type UserChallenge, type InsertUserChallenge
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;
  
  // Module methods
  getAllModules(): Promise<Module[]>;
  getModule(id: number): Promise<Module | undefined>;
  createModule(module: InsertModule): Promise<Module>;
  
  // User Progress methods
  getUserProgress(userId: number): Promise<UserProgress[]>;
  getUserModuleProgress(userId: number, moduleId: number): Promise<UserProgress | undefined>;
  updateUserProgress(progress: InsertUserProgress): Promise<UserProgress>;
  
  // Chat methods
  getChatSession(userId: number, sessionId: string): Promise<ChatSession | undefined>;
  createChatSession(session: InsertChatSession): Promise<ChatSession>;
  updateChatSession(id: number, messages: any[]): Promise<ChatSession | undefined>;
  
  // Challenge methods
  getDailyChallenges(): Promise<DailyChallenge[]>;
  getUserChallenges(userId: number): Promise<UserChallenge[]>;
  completeChallenge(challenge: InsertUserChallenge): Promise<UserChallenge>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User> = new Map();
  private modules: Map<number, Module> = new Map();
  private userProgress: Map<string, UserProgress> = new Map();
  private chatSessions: Map<number, ChatSession> = new Map();
  private dailyChallenges: Map<number, DailyChallenge> = new Map();
  private userChallenges: Map<string, UserChallenge> = new Map();
  private currentId = 1;

  constructor() {
    this.initializeData();
  }

  private initializeData() {
    // Sample modules
    const sampleModules: Module[] = [
      {
        id: 1,
        title: "Smart Budgeting",
        description: "Learn to create and manage budgets that work for your local economy and lifestyle",
        category: "budgeting",
        difficulty: "beginner",
        estimatedDuration: 45,
        prerequisites: [],
        content: {
          lessons: [
            { title: "Understanding Income and Expenses", duration: 15 },
            { title: "50/30/20 Rule Adapted", duration: 15 },
            { title: "Local Banking Tools", duration: 15 }
          ]
        },
        isActive: true,
        createdAt: new Date(),
      },
      {
        id: 2,
        title: "Smart Saving",
        description: "Discover local saving schemes and build emergency funds with region-specific strategies",
        category: "saving",
        difficulty: "beginner",
        estimatedDuration: 30,
        prerequisites: [],
        content: {
          lessons: [
            { title: "Emergency Fund Basics", duration: 10 },
            { title: "Local Saving Schemes", duration: 10 },
            { title: "Goal-Based Saving", duration: 10 }
          ]
        },
        isActive: true,
        createdAt: new Date(),
      },
      {
        id: 3,
        title: "Investment Basics",
        description: "Understand local investment options and build wealth through smart financial planning",
        category: "investing",
        difficulty: "intermediate",
        estimatedDuration: 60,
        prerequisites: ["saving"],
        content: {
          lessons: [
            { title: "Investment Fundamentals", duration: 20 },
            { title: "Local Investment Options", duration: 20 },
            { title: "Risk Management", duration: 20 }
          ]
        },
        isActive: true,
        createdAt: new Date(),
      },
    ];

    sampleModules.forEach(module => {
      this.modules.set(module.id, module);
    });

    // Sample daily challenges
    const sampleChallenges: DailyChallenge[] = [
      {
        id: 1,
        title: "Track Your Expenses",
        description: "Calculate your monthly expenses and identify 3 areas where you can save money",
        points: 50,
        category: "budgeting",
        difficulty: "beginner",
        content: {
          tasks: [
            "List all your monthly expenses",
            "Categorize expenses into needs vs wants",
            "Identify 3 potential savings areas"
          ]
        },
        isActive: true,
        createdAt: new Date(),
      }
    ];

    sampleChallenges.forEach(challenge => {
      this.dailyChallenges.set(challenge.id, challenge);
    });

    this.currentId = Math.max(
      Math.max(...Array.from(this.modules.keys())),
      Math.max(...Array.from(this.dailyChallenges.keys()))
    ) + 1;
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = {
      ...insertUser,
      id,
      preferredLanguage: insertUser.preferredLanguage || "en",
      region: insertUser.region || "global",
      currentLevel: insertUser.currentLevel || "beginner",
      totalPoints: 0,
      streakDays: 0,
      lastActiveDate: new Date(),
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Module methods
  async getAllModules(): Promise<Module[]> {
    return Array.from(this.modules.values()).filter(module => module.isActive);
  }

  async getModule(id: number): Promise<Module | undefined> {
    return this.modules.get(id);
  }

  async createModule(insertModule: InsertModule): Promise<Module> {
    const id = this.currentId++;
    const module: Module = {
      ...insertModule,
      id,
      difficulty: insertModule.difficulty || "beginner",
      prerequisites: insertModule.prerequisites || [],
      isActive: insertModule.isActive !== false,
      createdAt: new Date(),
    };
    this.modules.set(id, module);
    return module;
  }

  // Progress methods
  async getUserProgress(userId: number): Promise<UserProgress[]> {
    return Array.from(this.userProgress.values()).filter(
      progress => progress.userId === userId
    );
  }

  async getUserModuleProgress(userId: number, moduleId: number): Promise<UserProgress | undefined> {
    const key = `${userId}-${moduleId}`;
    return this.userProgress.get(key);
  }

  async updateUserProgress(insertProgress: InsertUserProgress): Promise<UserProgress> {
    const key = `${insertProgress.userId}-${insertProgress.moduleId}`;
    const existing = this.userProgress.get(key);
    
    const progress: UserProgress = {
      id: existing?.id || this.currentId++,
      ...insertProgress,
      progressPercentage: insertProgress.progressPercentage || 0,
      timeSpent: insertProgress.timeSpent || 0,
      completedAt: insertProgress.completedAt || null,
      score: insertProgress.score || null,
      lastAccessedAt: new Date(),
    };
    
    this.userProgress.set(key, progress);
    return progress;
  }

  // Chat methods
  async getChatSession(userId: number, sessionId: string): Promise<ChatSession | undefined> {
    return Array.from(this.chatSessions.values()).find(
      session => session.userId === userId && session.sessionId === sessionId
    );
  }

  async createChatSession(insertSession: InsertChatSession): Promise<ChatSession> {
    const id = this.currentId++;
    const session: ChatSession = {
      ...insertSession,
      id,
      language: insertSession.language || "en",
      region: insertSession.region || "global",
      messages: insertSession.messages || [],
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.chatSessions.set(id, session);
    return session;
  }

  async updateChatSession(id: number, messages: any[]): Promise<ChatSession | undefined> {
    const session = this.chatSessions.get(id);
    if (!session) return undefined;
    
    const updatedSession = {
      ...session,
      messages,
      updatedAt: new Date(),
    };
    this.chatSessions.set(id, updatedSession);
    return updatedSession;
  }

  // Challenge methods
  async getDailyChallenges(): Promise<DailyChallenge[]> {
    return Array.from(this.dailyChallenges.values()).filter(challenge => challenge.isActive);
  }

  async getUserChallenges(userId: number): Promise<UserChallenge[]> {
    return Array.from(this.userChallenges.values()).filter(
      challenge => challenge.userId === userId
    );
  }

  async completeChallenge(insertChallenge: InsertUserChallenge): Promise<UserChallenge> {
    const key = `${insertChallenge.userId}-${insertChallenge.challengeId}`;
    const challenge: UserChallenge = {
      id: this.currentId++,
      ...insertChallenge,
      completedAt: insertChallenge.completedAt || null,
      score: insertChallenge.score || null,
      createdAt: new Date(),
    };
    this.userChallenges.set(key, challenge);
    return challenge;
  }
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  // Module methods
  async getAllModules(): Promise<Module[]> {
    return await db.select().from(modules).where(eq(modules.isActive, true));
  }

  async getModule(id: number): Promise<Module | undefined> {
    const [module] = await db.select().from(modules).where(eq(modules.id, id));
    return module || undefined;
  }

  async createModule(insertModule: InsertModule): Promise<Module> {
    const [module] = await db
      .insert(modules)
      .values(insertModule)
      .returning();
    return module;
  }

  // Progress methods
  async getUserProgress(userId: number): Promise<UserProgress[]> {
    return await db.select().from(userProgress).where(eq(userProgress.userId, userId));
  }

  async getUserModuleProgress(userId: number, moduleId: number): Promise<UserProgress | undefined> {
    const progressList = await db
      .select()
      .from(userProgress)
      .where(eq(userProgress.userId, userId));
    return progressList.find(p => p.moduleId === moduleId);
  }

  async updateUserProgress(insertProgress: InsertUserProgress): Promise<UserProgress> {
    const existing = await this.getUserModuleProgress(insertProgress.userId, insertProgress.moduleId);
    
    if (existing) {
      const [progress] = await db
        .update(userProgress)
        .set({
          ...insertProgress,
          lastAccessedAt: new Date(),
        })
        .where(eq(userProgress.id, existing.id))
        .returning();
      return progress;
    } else {
      const [progress] = await db
        .insert(userProgress)
        .values({
          ...insertProgress,
          lastAccessedAt: new Date(),
        })
        .returning();
      return progress;
    }
  }

  // Chat methods
  async getChatSession(userId: number, sessionId: string): Promise<ChatSession | undefined> {
    const sessions = await db
      .select()
      .from(chatSessions)
      .where(eq(chatSessions.userId, userId));
    return sessions.find(s => s.sessionId === sessionId);
  }

  async createChatSession(insertSession: InsertChatSession): Promise<ChatSession> {
    const [session] = await db
      .insert(chatSessions)
      .values(insertSession)
      .returning();
    return session;
  }

  async updateChatSession(id: number, messages: any[]): Promise<ChatSession | undefined> {
    const [session] = await db
      .update(chatSessions)
      .set({
        messages,
        updatedAt: new Date(),
      })
      .where(eq(chatSessions.id, id))
      .returning();
    return session;
  }

  // Challenge methods
  async getDailyChallenges(): Promise<DailyChallenge[]> {
    return await db.select().from(dailyChallenges).where(eq(dailyChallenges.isActive, true));
  }

  async getUserChallenges(userId: number): Promise<UserChallenge[]> {
    return await db.select().from(userChallenges).where(eq(userChallenges.userId, userId));
  }

  async completeChallenge(insertChallenge: InsertUserChallenge): Promise<UserChallenge> {
    const [challenge] = await db
      .insert(userChallenges)
      .values(insertChallenge)
      .returning();
    return challenge;
  }
}

// Initialize database with sample data
async function initializeDatabase() {
  try {
    const db = new DatabaseStorage();
    
    // Create demo user if it doesn't exist
    const existingUser = await db.getUserByEmail('demo@zerodayfinancing.com');
    if (!existingUser) {
      await db.createUser({
        username: 'demo_user',
        email: 'demo@zerodayfinancing.com',
        password: 'password123',
        preferredLanguage: 'en',
        region: 'india',
        currentLevel: 'beginner',
      });
    }

    // Create sample modules if they don't exist
    const existingModules = await db.getAllModules();
    if (existingModules.length === 0) {
      const sampleModules = [
        {
          title: "Smart Budgeting",
          description: "Learn to create and manage budgets that work for your local economy and lifestyle",
          category: "budgeting",
          difficulty: "beginner" as const,
          estimatedDuration: 45,
          prerequisites: [],
          content: {
            lessons: [
              { title: "Understanding Income and Expenses", duration: 15 },
              { title: "50/30/20 Rule Adapted", duration: 15 },
              { title: "Local Banking Tools", duration: 15 }
            ]
          },
          isActive: true,
        },
        {
          title: "Smart Saving",
          description: "Discover local saving schemes and build emergency funds with region-specific strategies",
          category: "saving",
          difficulty: "beginner" as const,
          estimatedDuration: 30,
          prerequisites: [],
          content: {
            lessons: [
              { title: "Emergency Fund Basics", duration: 10 },
              { title: "Local Saving Schemes", duration: 10 },
              { title: "Goal-Based Saving", duration: 10 }
            ]
          },
          isActive: true,
        },
        {
          title: "Investment Basics",
          description: "Understand local investment options and build wealth through smart financial planning",
          category: "investing",
          difficulty: "intermediate" as const,
          estimatedDuration: 60,
          prerequisites: ["saving"],
          content: {
            lessons: [
              { title: "Investment Fundamentals", duration: 20 },
              { title: "Local Investment Options", duration: 20 },
              { title: "Risk Management", duration: 20 }
            ]
          },
          isActive: true,
        },
      ];

      for (const module of sampleModules) {
        await db.createModule(module);
      }
    }

    return db;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    return new MemStorage();
  }
}

// Storage initialization - synchronous export with async initialization
let _storage: IStorage;

if (process.env.DATABASE_URL) {
  // Initialize with database
  _storage = new MemStorage(); // Temporary fallback
  initializeDatabase().then(initializedStorage => {
    _storage = initializedStorage;
  }).catch(error => {
    console.error('Database initialization failed, using memory storage:', error);
    _storage = new MemStorage();
  });
} else {
  _storage = new MemStorage();
}

export const storage = _storage;
