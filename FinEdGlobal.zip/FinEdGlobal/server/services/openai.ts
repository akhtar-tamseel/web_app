import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || ""
});

export interface ChatMessage {
  role: "user" | "assistant" | "system";
  content: string;
  timestamp: Date;
}

export interface ChatResponse {
  message: string;
  suggestions?: string[];
}

export async function generateFinancialAdvice(
  userMessage: string,
  language: string = "en",
  region: string = "global",
  userContext?: {
    currentLevel?: string;
    completedModules?: string[];
    preferences?: any;
  }
): Promise<ChatResponse> {
  try {
    const systemPrompt = `You are a friendly and knowledgeable AI financial mentor for Zero Day Financing, specialized in providing culturally-adapted financial advice. Your role is to:

1. Provide personalized financial guidance based on the user's region (${region}) and language (${language})
2. Adapt advice to local economic conditions, banking systems, and cultural norms
3. Use region-specific examples, local currency, and relevant financial products
4. Keep responses concise, practical, and actionable
5. Suggest relevant learning modules when appropriate
6. Be encouraging and supportive of financial literacy goals

User Context:
- Language: ${language}
- Region: ${region}
- Level: ${userContext?.currentLevel || "beginner"}
- Completed Modules: ${userContext?.completedModules?.join(", ") || "none"}

Respond in a helpful, encouraging tone. If you mention specific financial products or services, ensure they are relevant to the user's region. Always prioritize financial safety and responsible money management.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userMessage }
      ],
      max_tokens: 500,
      temperature: 0.7,
    });

    const assistantMessage = response.choices[0].message.content || "I'm sorry, I couldn't process your request right now.";

    // Generate follow-up suggestions
    const suggestionsResponse = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `Based on the user's question about finance, suggest 2-3 short follow-up questions they might want to ask. Keep suggestions specific to ${region} and relevant to their financial learning journey. Format as a JSON array of strings.`
        },
        { role: "user", content: userMessage },
        { role: "assistant", content: assistantMessage }
      ],
      response_format: { type: "json_object" },
      max_tokens: 200,
    });

    let suggestions: string[] = [];
    try {
      const suggestionsData = JSON.parse(suggestionsResponse.choices[0].message.content || "{}");
      suggestions = suggestionsData.suggestions || [];
    } catch (e) {
      console.error("Failed to parse suggestions:", e);
    }

    return {
      message: assistantMessage,
      suggestions
    };
  } catch (error) {
    console.error("OpenAI API error:", error);
    throw new Error("Failed to generate financial advice. Please try again later.");
  }
}

export async function generateModuleContent(
  topic: string,
  level: string,
  region: string,
  language: string
): Promise<any> {
  try {
    const prompt = `Create educational content for a financial literacy module about "${topic}" for ${level} level learners in ${region}. 

Requirements:
- Adapt examples and case studies to ${region}'s economic context
- Include local financial products, banking systems, and regulations
- Use culturally appropriate scenarios and values
- Structure content with clear learning objectives
- Include practical exercises and real-world applications
- Format as JSON with sections: introduction, lessons, exercises, summary

Language: ${language}
Region: ${region}
Level: ${level}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
      max_tokens: 1500,
    });

    return JSON.parse(response.choices[0].message.content || "{}");
  } catch (error) {
    console.error("Failed to generate module content:", error);
    throw new Error("Failed to generate educational content");
  }
}
